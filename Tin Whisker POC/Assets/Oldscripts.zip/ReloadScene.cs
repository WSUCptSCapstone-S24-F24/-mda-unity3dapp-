using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadSceneAdditively : MonoBehaviour
{
    private Scene loadedScene;
    public string sceneName;
    private bool isSceneLoaded = false;

    public void LoadScene(string sceneName)
    {
        if(!isSceneLoaded)
        {
            StartCoroutine(LoadSceneAsync(sceneName));
        }
    }

    IEnumerator LoadSceneAsync(string sceneName)
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Additive);

        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        loadedScene = SceneManager.GetSceneByName(sceneName);
        isSceneLoaded = true;
    }

    public void ReloadScene()
    {
        if(isSceneLoaded)
        {
            SceneManager.UnloadSceneAsync(loadedScene);

            StartCoroutine(ReloadSceneAsync());
        }
    }

    IEnumerator ReloadSceneAsync()
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(loadedScene.name, LoadSceneMode.Additive);

        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        SceneManager.SetActiveScene(SceneManager.GetSceneByName(loadedScene.name));
    }
}